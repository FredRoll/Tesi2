# survey_example

1. Creare un ambiente virtuale .venv
``` python -m venv .venv ```
2. Attivare l'ambiente virtuale (Windows)
``` .venv\Scripts\Activate.ps1 ```
3. Installare il pacchetto "survey"
``` pip install src\survey-0.1-py3-none-any.whl ```
4. Impostare la configurazione del db nel file config.py

4. Lanciare main.py
``` python main.py ```